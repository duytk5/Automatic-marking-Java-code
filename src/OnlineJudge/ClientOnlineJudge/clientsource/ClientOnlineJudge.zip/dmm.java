

    public void setName(String name) {
        this.name = name;
    }
}
e Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HOANG FUCK HELLO
 */
public class DemoMain {
    public static void main(String[] args) {
        int n;
        int a[] = new int[100];
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
        for (int i=0;i<n;i++){
            a[i] = sc.nextInt();
            System.out.println(a[i]);
        }
        Student st1 = new Student(1,"hiep");
        System.out.println(st1.getName());
    }
    }
class Student {
    private int id;
    private String name;

    public Student(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
